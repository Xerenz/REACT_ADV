import './App.css';

import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Home from './Home';
import Cart from './Cart';

function App() {
  return (
    <div className="app">
      <BrowserRouter>
      <Routes>
         <Route path='/cart' element={<Cart />}/>
         <Route path='/' element={<Home />}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;