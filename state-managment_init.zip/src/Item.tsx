import './item.css'
import { Item } from './types/Item'

function Item(item:Item) {
  let {id, title, image, price} = item;
  return (
    <div className="item">
      <div className="item__info">
        <p className="item__title">{title}</p>
        <p className="item__price">
          <small>$</small>
          <strong>{price}</strong>
        </p>
      </div>
      <img
        src={image}
        alt="item"
      />
      <button>Add to Cart</button>
    </div>
  )
}

export default Item