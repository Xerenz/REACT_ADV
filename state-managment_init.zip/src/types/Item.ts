export interface Item {
    id:number, 
    title:string, 
    image:string, 
    price:number,
    quantity?:number
}